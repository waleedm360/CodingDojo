from django.apps import AppConfig


class SoloAppConfig(AppConfig):
    name = 'solopro'
